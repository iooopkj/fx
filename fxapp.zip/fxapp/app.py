#!/usr/bin/env python3
"""ดับเบิลคลิกเพื่อใช้เป็นแอป: ตั้งค่าครั้งแรกอัตโนมัติ → เปิดเซิร์ฟเวอร์ → เปิดหน้าต่างแอป (Chrome/Edge --app)"""
import os, shutil, subprocess, sys, threading, time, webbrowser
from http.server import ThreadingHTTPServer
import server
PORT = int(os.environ.get("FX_PORT", 8000)); URL = f"http://127.0.0.1:{PORT}"
# ครั้งแรก: หน้าต่างแอปจะเปิดหน้าตั้งค่า (ชื่อ/รหัสผ่าน/อีเมล OTP) ให้เอง
HOST = os.environ.get("FX_HOST", "0.0.0.0")   # 0.0.0.0 = เครื่องอื่นใน Wi-Fi เดียวกันเข้าได้; ตั้ง FX_HOST=127.0.0.1 ถ้าไม่ต้องการ
srv = ThreadingHTTPServer((HOST, PORT), server.H)
threading.Thread(target=srv.serve_forever, daemon=True).start()
cands = ["google-chrome", "chromium", "chrome", "msedge", "microsoft-edge",
         r"C:\Program Files\Google\Chrome\Application\chrome.exe", r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
         "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
exe = next((shutil.which(x) or (x if os.path.exists(x) else None) for x in cands if shutil.which(x) or os.path.exists(x)), None)
p = subprocess.Popen([exe, f"--app={URL}", "--window-size=480,860"]) if exe else None
if not p: webbrowser.open(URL)
print("เครื่องอื่นใน Wi-Fi เดียวกันเปิด:", ", ".join(server.lan_urls(PORT)) or "(ยังไม่พบ Wi-Fi)")
print(f"แอปรันที่ {URL}  (ปิดหน้าต่างแล้วกด Ctrl+C เพื่อหยุดเซิร์ฟเวอร์)")
try:
    while True: time.sleep(1)
except KeyboardInterrupt: pass
