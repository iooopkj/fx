"""Playwright e2e: login → OTP#1 → EA ส่งออเดอร์ → ซิงก์เข้าปฏิทิน → OTP#2.
ใช้: FX_USER=.. FX_PASS=.. FX_TOTP=<secret> FX_EAKEY=<key> python tests/e2e.py   (เซิร์ฟเวอร์ต้องรันอยู่)"""
import base64, hashlib, hmac, os, struct, time, json
from playwright.sync_api import sync_playwright
BASE = os.environ.get("FX_BASE", "http://127.0.0.1:8000"); E = os.environ

def totp(sec, n):
    h = hmac.new(base64.b32decode(sec), struct.pack(">Q", n), "sha1").digest(); o = h[19] & 15
    return "%06d" % ((struct.unpack(">I", h[o:o+4])[0] & 0x7fffffff) % 1000000)
def code(off=0): return totp(E["FX_TOTP"], int(time.time() // 30) + off)

with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(); pg.goto(BASE)
    pg.fill("#user", E["FX_USER"]); pg.fill("#pass", E["FX_PASS"]); pg.click("#go")
    pg.wait_for_selector("#otp:not([hidden])")
    for i, ch in enumerate(code()): pg.locator("#otpb input").nth(i).fill(ch)   # OTP ครั้งที่ 1
    pg.wait_for_selector("body.in", timeout=5000); print("✔ login + OTP#1")
    r = pg.request.post(BASE + "/api/ea/trade", headers={"X-API-Key": E["FX_EAKEY"]},
        data=json.dumps([{"ext": "e2e-%d" % time.time(), "date": time.strftime("%Y-%m-%d"), "pair": "EURUSD", "pl": 12.34, "note": "e2e"}]))
    assert r.ok and r.json()["added"] == 1; print("✔ EA ส่งออเดอร์")
    pg.evaluate("window.fxSync()"); pg.wait_for_timeout(800)
    assert "EURUSD" in pg.evaluate("localStorage.getItem('tc_v1')||''"); print("✔ ออเดอร์เข้าปฏิทิน")
    assert pg.request.get(BASE + "/api/export").status == 403; print("✔ export ถูกบล็อกก่อน OTP#2")
    assert pg.request.post(BASE + "/api/stepup", data=json.dumps({"code": code()})).status == 401; print("✔ ใช้รหัสเดิมซ้ำไม่ได้")
    assert pg.request.post(BASE + "/api/stepup", data=json.dumps({"code": code(1)})).ok; print("✔ OTP#2 (รหัสถัดไป)")
    assert pg.request.get(BASE + "/api/export").ok; print("✔ export ผ่าน"); b.close()
