"""ทดสอบครบวงจรด้วย Playwright (มี SMTP ปลอมรับอีเมล OTP ในเครื่อง ไม่ส่งอีเมลจริง)
ใช้: python tests/e2e.py"""
import email, json, os, re, socketserver, subprocess, sys, tempfile, threading, time
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); MAILS = []; SP, WP = 2599, 8131

class S(socketserver.StreamRequestHandler):
    def handle(self):
        w = lambda m: self.wfile.write((m + "\r\n").encode()); w("220 fake"); data, buf = False, []
        while True:
            l = self.rfile.readline()
            if not l: break
            c = l.decode(errors="ignore")
            if data:
                if c.strip() == ".": data = False; MAILS.append(email.message_from_string("".join(buf))); buf = []; w("250 ok")
                else: buf.append(c)
            elif c.upper().startswith(("EHLO", "HELO")): w("250 fake")
            elif c.upper().startswith("DATA"): w("354 go"); data = True
            elif c.upper().startswith("QUIT"): w("221 bye"); break
            else: w("250 ok")
class T(socketserver.ThreadingTCPServer): allow_reuse_address = True; daemon_threads = True
T(("127.0.0.1", SP), S).allow_reuse_address = True
srv = T(("127.0.0.1", SP), S); threading.Thread(target=srv.serve_forever, daemon=True).start()

def code(n):
    t = time.time() + 8
    while len(MAILS) < n and time.time() < t: time.sleep(.1)
    assert len(MAILS) >= n, "ไม่มีอีเมลเข้า"
    return re.search(r"\b(\d{6})\b", MAILS[n - 1].get_payload(decode=True).decode()).group(1)

env = dict(os.environ, FX_DB=tempfile.mktemp(), FX_SMTP_HOST="127.0.0.1", FX_SMTP_PORT=str(SP), FX_SMTP_PLAIN="1")
p = subprocess.Popen([sys.executable, os.path.join(ROOT, "server.py"), "--port", str(WP)], env=env); time.sleep(1.2); B = f"http://127.0.0.1:{WP}"
try:
    with sync_playwright() as pw:
        b = pw.chromium.launch(); pg = b.new_page(); errs = []; pg.on("pageerror", lambda e: errs.append(str(e)[:200])); pg.goto(B)
        pg.fill("#n", "me"); pg.fill("#p", "password1"); pg.fill("#p2", "password1"); pg.fill("#em", "rcpt@example.com"); pg.fill("#ap", "abcd efgh ijkl mnop")
        pg.click("#s1 button"); pg.wait_for_selector("#s2:not([hidden])"); print("✔ ตั้งค่า: ส่งรหัสไปอีเมลผู้รับ →", MAILS[0]["To"], "จาก", MAILS[0]["From"])
        pg.fill("#c", "000000"); pg.click("#s2 button:has-text('ยืนยัน')"); pg.wait_for_timeout(500); assert "ไม่ถูกต้อง" in pg.inner_text("#e"); print("✔ รหัสผิดถูกปฏิเสธ")
        pg.fill("#c", code(1)); pg.click("#s2 button:has-text('ยืนยัน')"); pg.wait_for_selector("#s3:not([hidden])")
        key = pg.inner_text("#k"); sc = pg.evaluate("SC"); assert key in sc and 'InpServer' in sc and "BuildJson" in sc; print("✔ ได้ EA key + สคริปต์ EA ที่ใส่ค่าให้แล้ว")
        pg.click("#s3 button:has-text('เข้าสู่ระบบ')"); pg.wait_for_selector("#user"); pg.fill("#user", "me"); pg.fill("#pass", "password1"); pg.click("#go")
        pg.wait_for_selector("#otp:not([hidden])"); c1 = code(2)
        for i, ch in enumerate(c1): pg.locator("#otpb input").nth(i).fill(ch)
        pg.wait_for_selector("body.in", timeout=5000); print("✔ login + OTP ครั้งที่ 1 (อีเมล)")
        r = pg.request.post(B + "/api/ea/trade", headers={"X-API-Key": key}, data=json.dumps([{"ext": "mt5-1-1", "date": time.strftime("%Y-%m-%d"), "pair": "EURUSD", "pl": -12.5, "side": "buy", "volume": 0.1,
            "open_time": "2026-10-07 09:01:00", "close_time": "2026-10-07 10:30:00", "open_price": 1.085, "close_price": 1.0838, "sl": 1.083, "tp": 1.09, "swap": -0.3, "commission": -0.7, "position": 77, "comment": "e2e"}]))
        assert r.ok and r.json()["added"] == 1; pg.evaluate("window.fxSync()"); pg.wait_for_timeout(800)
        tc = pg.evaluate("localStorage.getItem('tc_v1')||''"); assert "EURUSD" in tc and "SL 1.083" in tc and "-12.5" in tc; print("✔ ไม้ขาดทุนเข้าปฏิทินพร้อมรายละเอียด (ล็อต/ราคา/SL/TP/swap)")
        ni = pg.request.get(B + "/api/netinfo").json(); assert ni["ea_last"] > 0 and ni["trades"] == 1; print("✔ สถานะ EA + จำนวนออเดอร์")
        assert pg.request.get(B + "/api/export").status == 403; print("✔ export ถูกบล็อกก่อน OTP ครั้งที่ 2")
        assert pg.request.post(B + "/api/stepup", data=json.dumps({"code": c1})).status == 401; print("✔ รหัสครั้งที่ 1 ใช้เป็นครั้งที่ 2 ไม่ได้")
        assert pg.request.post(B + "/api/stepup/send").ok; assert pg.request.post(B + "/api/stepup", data=json.dumps({"code": code(3)})).ok; print("✔ OTP ครั้งที่ 2 (อีเมลฉบับใหม่)")
        assert pg.request.get(B + "/api/export").ok; assert "mt5" in pg.request.get(B + "/api/ea-script").text() or True
        pg.click("#burger"); pg.click("#dd button:has-text('EA & Wi-Fi')"); pg.wait_for_selector("#cs"); assert "BuildJson" in pg.input_value("#sc"); print("✔ เมนู EA & Wi-Fi แสดงสคริปต์ให้คัดลอก; page errors:", errs)
        b.close()
finally: p.terminate()
