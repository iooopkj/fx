#!/bin/sh
# คัดลอกไฟล์เว็บ/เซิร์ฟเวอร์จากโฟลเดอร์หลักเข้าโปรเจกต์ Android (รันทุกครั้งที่แก้ server.py / index.html)
cd "$(dirname "$0")/.." || exit 1
cp server.py android/app/src/main/python/server.py
cp index.html sync.js manifest.webmanifest sw.js icon-192.png icon-512.png android/app/src/main/assets/web/
cp icon-192.png android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png
cp icon-fg.png android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_foreground.png
cp ea/TradeLogger.mq5 android/app/src/main/assets/web/TradeLogger.mq5
