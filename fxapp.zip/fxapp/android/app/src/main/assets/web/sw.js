// PWA shell: ไม่แคชข้อมูล/API เพื่อไม่ให้ข้อมูลเก่าหรือหลุดข้าม session
self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(clients.claim()));
self.addEventListener('fetch',e=>{if(e.request.mode==='navigate')e.respondWith(fetch(e.request).catch(()=>new Response('<meta charset=utf-8><body style="font-family:sans-serif;padding:30px">ออฟไลน์ — เซิร์ฟเวอร์ยังไม่เปิดหรือเชื่อมต่อไม่ได้</body>',{headers:{'Content-Type':'text/html'}})))});
