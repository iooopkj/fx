/* ฉีดเข้า index.html โดย server: PWA + สำรอง localStorage + OTP ครั้งที่ 2 (อีเมล) + เมนู EA & Wi-Fi */
(()=>{const lk=document.createElement('link');lk.rel='manifest';lk.href='/manifest.webmanifest';document.head.append(lk);if('serviceWorker'in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});
const KEYS=['tc_v1','mk_name','mk_avatar','mk_accent'],ls=localStorage;
const api=(u,o)=>fetch(u,Object.assign({credentials:'same-origin',cache:'no-store'},o));
const J={'Content-Type':'application/json'},post=(u,b)=>api(u,{method:'POST',headers:J,body:JSON.stringify(b||{})});
const esc=t=>String(t).replace(/[<>&"]/g,'');
// ข้อความหน้า OTP ครั้งที่ 1: ส่งทางอีเมล
document.querySelectorAll('p.sub').forEach(p=>{if(p.textContent.includes('Authenticator'))p.textContent='กรอกรหัส 6 หลักที่ส่งไปทางอีเมลของคุณ'});
let last='',timer;
const snap=()=>{const d={};KEYS.forEach(k=>{const v=ls.getItem(k);if(v!=null)d[k]=v});return d};
async function pull(){try{const r=await api('/api/store');if(!r.ok)return;const s=(await r.json()).data,seen=+ls.getItem('fx_store_ts')||0;let ch=0,mx=seen;
 for(const k of KEYS){const o=s[k];if(!o)continue;mx=Math.max(mx,o.ts);if((ls.getItem(k)==null||o.ts>seen&&JSON.stringify(snap())===last)&&ls.getItem(k)!==o.v){ls.setItem(k,o.v);ch=1}}
 ls.setItem('fx_store_ts',String(mx));last=JSON.stringify(snap());if(ch&&window.tcPL)window.tcPL()}catch(e){}}
async function push(){const d=snap(),j=JSON.stringify(d);if(j===last)return;try{const r=await post('/api/store',{data:d});if(r.ok){last=j;ls.setItem('fx_store_ts',String((await r.json()).ts))}}catch(e){}}
const st=window.fxStart;window.fxStart=()=>{if(st)st();pull().then(()=>{clearInterval(timer);timer=setInterval(push,10000)})};
addEventListener('pagehide',()=>{const d=snap();if(JSON.stringify(d)!==last)navigator.sendBeacon&&navigator.sendBeacon('/api/store',new Blob([JSON.stringify({data:d})],{type:'application/json'}))});
const sheet=h=>{const o=document.createElement('div');o.style.cssText='position:fixed;inset:0;z-index:99;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;font-family:Kanit,sans-serif';
 o.innerHTML='<div style="background:#fff3e0;color:#2b1a08;border-radius:18px;padding:18px;width:min(92%,360px);max-height:88%;overflow:auto">'+h+'</div>';document.body.append(o);return o};
const BTN='width:100%;padding:10px;margin-top:6px;border:0;border-radius:12px;background:#ff9a2e;font:inherit;font-weight:600',LNK='width:100%;padding:8px;border:0;background:none;font:inherit',BOX='display:block;background:#fff;padding:8px;border-radius:8px;white-space:pre-wrap;word-break:break-all;font-size:12px';
const copy=t=>{const a=document.createElement('textarea');a.value=t;document.body.append(a);a.select();try{document.execCommand('copy')}catch(e){}a.remove()};
// ---- OTP ครั้งที่ 2 (ส่งรหัสใหม่ทางอีเมล) ----
window.fxStepUp=()=>new Promise(res=>{api('/api/me').then(r=>r.json()).then(async m=>{if(m.stepup)return res(true);
 const o=sheet('<b>ยืนยัน OTP ครั้งที่ 2</b><p id=t style="font-size:13px;margin:6px 0">กำลังส่งรหัสไปทางอีเมล...</p><input inputmode="numeric" maxlength="6" style="width:100%;font-size:22px;text-align:center;letter-spacing:6px;padding:8px;border-radius:10px;border:1px solid #c90;box-sizing:border-box"><div id="e" style="color:#d12f45;font-size:13px;min-height:18px"></div><button id="ok" style="'+BTN+'">ยืนยัน</button><button id="rs" style="'+LNK+'">ส่งรหัสอีกครั้ง</button><button id="no" style="'+LNK+'">ยกเลิก</button>'),
 i=o.querySelector('input'),e=o.querySelector('#e'),t=o.querySelector('#t');
 const send=async()=>{const r=await post('/api/stepup/send'),j=await r.json();t.textContent=r.ok?'ส่งรหัสไปที่ '+esc(j.sent_to)+' แล้ว (ใช้ได้ 5 นาที)':esc(j.error)};
 send();i.focus();o.querySelector('#rs').onclick=send;o.querySelector('#no').onclick=()=>{o.remove();res(false)};
 o.querySelector('#ok').onclick=async()=>{const r=await post('/api/stepup',{code:i.value});if(r.ok){o.remove();res(true)}else e.textContent=(await r.json()).error}})});
['openKV','openBackup'].forEach(n=>{let f=window[n];Object.defineProperty(window,n,{configurable:true,get(){return f&&window.FXSRV?async function(){if(await window.fxStepUp())f.apply(this,arguments)}:f},set(v){f=v}})});
// ---- เมนู "EA & Wi-Fi" ----
(()=>{const dd=document.getElementById('dd');if(!dd)return;const b=document.createElement('button');b.textContent='📡 EA & Wi-Fi';
 b.onclick=async()=>{dd.classList.remove('on');const [ni,sc]=await Promise.all([api('/api/netinfo').then(r=>r.ok?r.json():{urls:[]}),api('/api/ea-script').then(r=>r.ok?r.text():'')]);
  const ago=ni.ea_last?Math.max(0,Math.round(Date.now()/1000-ni.ea_last)):null,stt=ago===null?'ยังไม่เคยเชื่อมต่อ':(ago<120?'🟢 เชื่อมต่ออยู่ ('+ago+' วิที่แล้ว)':'🟠 ล่าสุด '+Math.round(ago/60)+' นาทีที่แล้ว');
  const o=sheet('<b>📡 EA & Wi-Fi</b><p style="font-size:13px;margin:8px 0 2px">ที่อยู่เว็บ (เครื่องใน Wi-Fi เดียวกันเปิดได้ / ใส่ใน InpServer ของ EA)</p><code style="'+BOX+'">'+(ni.urls.length?ni.urls.map(esc).join('\n'):'ยังไม่พบ Wi-Fi')+'</code>'
   +'<p style="font-size:13px;margin:10px 0 2px">สถานะ EA: '+stt+' · ออเดอร์ทั้งหมด '+(ni.trades||0)+'<br><small>EA ทำงานคู่กับแอปนี้ ถ้าปิดแอป EA จะส่งไม่ได้ (เก็บคิวไว้ส่งให้ใหม่ตอนเปิดแอป)</small></p>'
   +'<p style="font-size:13px;margin:10px 0 2px">สคริปต์ EA สำหรับ MT5 (วางในไฟล์ TradeLogger.mq5 → คอมไพล์ → ลงกราฟ)</p><textarea id=sc readonly style="width:100%;height:90px;font-size:11px;box-sizing:border-box"></textarea><button id=cs style="'+BTN+'">📋 คัดลอกสคริปต์</button>'
   +'<p style="font-size:12px;margin:8px 0 2px">API key ถูกซ่อนไว้ ถ้าลืมให้สร้างใหม่ (ต้อง OTP ครั้งที่ 2, คีย์เก่าใช้ไม่ได้) แล้วสคริปต์ด้านบนจะใส่คีย์ใหม่ให้เอง</p><code id=k2 style="'+BOX+';display:none"></code><button id=nk style="'+BTN+'">🔑 สร้าง API key ใหม่</button><button id=cl style="'+LNK+'">ปิด</button>'),ta=o.querySelector('#sc');ta.value=sc;
  o.querySelector('#cl').onclick=()=>o.remove();o.querySelector('#cs').onclick=()=>{copy(ta.value);o.querySelector('#cs').textContent='✅ คัดลอกแล้ว'};
  o.querySelector('#nk').onclick=async()=>{if(!await window.fxStepUp())return;const r=await post('/api/ea-key/rotate'),k=o.querySelector('#k2');k.style.display='block';
   if(!r.ok){k.textContent='สร้างไม่สำเร็จ';return}const key=(await r.json()).key;k.textContent=key;ta.value=ta.value.replace(/(input\s+string\s+InpApiKey\s*=\s*")[^"]*(")/,(m,a,c)=>a+key+c)}};
 dd.append(b)})();
})();
