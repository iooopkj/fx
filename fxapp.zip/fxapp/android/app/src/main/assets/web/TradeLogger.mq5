//+------------------------------------------------------------------+
//| TradeLogger.mq5 — บันทึกทุกไม้ที่ปิด (กำไร/ขาดทุน) เข้าปฏิทินเทรด    |
//| ส่งข้อมูลครบ: คู่เงิน ฝั่ง ล็อต ราคาเข้า-ออก เวลาเข้า-ออก SL TP     |
//|              swap คอมมิชชัน กำไรสุทธิ ticket magic คอมเมนต์          |
//| ติดตั้ง: Tools > Options > Expert Advisors > Allow WebRequest      |
//|          แล้วเพิ่มที่อยู่เซิร์ฟเวอร์ (เช่น http://192.168.1.20:8000)   |
//+------------------------------------------------------------------+
#property copyright "FX Calendar"
#property version   "2.00"
input string InpServer       = "http://127.0.0.1:8000"; // ที่อยู่เซิร์ฟเวอร์ (แอป)
input string InpApiKey       = "";                      // EA API key
input int    InpBackfillDays = 30;                      // ส่งย้อนหลังตอนเริ่ม (เซิร์ฟเวอร์กันซ้ำให้)
input int    InpRetrySec     = 15;                      // ลองส่งใหม่/เช็กการเชื่อมต่อทุก N วินาที

string g_queue[];

string Esc(string s){ StringReplace(s,"\\","\\\\"); StringReplace(s,"\"","\\\""); StringReplace(s,"\r"," "); StringReplace(s,"\n"," "); return s; }
string DStr(datetime t){ string s=TimeToString(t,TIME_DATE); StringReplace(s,".","-"); return s; }
string TStr(datetime t){ string s=TimeToString(t,TIME_DATE|TIME_SECONDS); StringReplace(s,".","-"); return s; }
string N(double v,int d){ return DoubleToString(v,d); }

// สร้าง JSON ของดีลที่ "ปิดออเดอร์" (คืน "" ถ้าไม่ใช่ดีลปิด)
string BuildJson(const ulong deal)
{
   if(!HistoryDealSelect(deal)){ HistorySelect(0,TimeCurrent()+86400); if(!HistoryDealSelect(deal)) return ""; }
   ENUM_DEAL_ENTRY en=(ENUM_DEAL_ENTRY)HistoryDealGetInteger(deal,DEAL_ENTRY);
   ENUM_DEAL_TYPE  ty=(ENUM_DEAL_TYPE)HistoryDealGetInteger(deal,DEAL_TYPE);
   if(en!=DEAL_ENTRY_OUT && en!=DEAL_ENTRY_OUT_BY && en!=DEAL_ENTRY_INOUT) return "";
   if(ty!=DEAL_TYPE_BUY && ty!=DEAL_TYPE_SELL) return "";

   // อ่านค่าของดีลปิดให้ครบก่อน (เพราะขั้นต่อไปจะเปลี่ยนชุดประวัติที่เลือก)
   ulong    pos   = (ulong)HistoryDealGetInteger(deal,DEAL_POSITION_ID);
   string   sym   = HistoryDealGetString(deal,DEAL_SYMBOL);
   string   cmt   = HistoryDealGetString(deal,DEAL_COMMENT);
   long     magic = HistoryDealGetInteger(deal,DEAL_MAGIC);
   datetime ct    = (datetime)HistoryDealGetInteger(deal,DEAL_TIME);
   double   vol   = HistoryDealGetDouble(deal,DEAL_VOLUME);
   double   cp    = HistoryDealGetDouble(deal,DEAL_PRICE);
   double   sl    = HistoryDealGetDouble(deal,DEAL_SL);
   double   tp    = HistoryDealGetDouble(deal,DEAL_TP);
   double   profit= HistoryDealGetDouble(deal,DEAL_PROFIT);
   double   swap  = HistoryDealGetDouble(deal,DEAL_SWAP);
   double   com   = HistoryDealGetDouble(deal,DEAL_COMMISSION);
   double   fee   = HistoryDealGetDouble(deal,DEAL_FEE);
   string   side  = (ty==DEAL_TYPE_SELL) ? "buy" : "sell";   // ดีลปิดฝั่ง Sell = ออเดอร์ Buy

   // ข้อมูลตอนเข้าไม้ (ราคา/เวลา/คอมมิชชันตอนเปิด)
   datetime ot=ct; double op=cp, evol=0, ecom=0, efee=0; bool got=false;
   if(HistorySelectByPosition(pos))
   {
      for(int i=0;i<HistoryDealsTotal();i++)
      {
         ulong d=HistoryDealGetTicket(i); if(d==0) continue;
         if((ENUM_DEAL_ENTRY)HistoryDealGetInteger(d,DEAL_ENTRY)!=DEAL_ENTRY_IN) continue;
         if(!got){ ot=(datetime)HistoryDealGetInteger(d,DEAL_TIME); op=HistoryDealGetDouble(d,DEAL_PRICE); got=true; }
         evol+=HistoryDealGetDouble(d,DEAL_VOLUME);
         ecom+=HistoryDealGetDouble(d,DEAL_COMMISSION); efee+=HistoryDealGetDouble(d,DEAL_FEE);
      }
   }
   if(got && MathAbs(evol-vol)<0.0000001){ com+=ecom; fee+=efee; }   // ปิดทั้งไม้ในดีลเดียว → รวมค่าคอมตอนเปิด
   double pl=profit+swap+com+fee;
   int dg=(int)SymbolInfoInteger(sym,SYMBOL_DIGITS); if(dg<=0) dg=5;

   string j="{";
   j+="\"ext\":\"mt5-"+(string)AccountInfoInteger(ACCOUNT_LOGIN)+"-"+(string)deal+"\"";
   j+=",\"date\":\""+DStr(ct)+"\"";
   j+=",\"pair\":\""+Esc(sym)+"\"";
   j+=",\"pl\":"+N(pl,2);
   j+=",\"side\":\""+side+"\"";
   j+=",\"volume\":"+N(vol,2);
   j+=",\"open_time\":\""+TStr(ot)+"\",\"close_time\":\""+TStr(ct)+"\"";
   j+=",\"open_price\":"+N(op,dg)+",\"close_price\":"+N(cp,dg);
   j+=",\"sl\":"+N(sl,dg)+",\"tp\":"+N(tp,dg);
   j+=",\"profit\":"+N(profit,2)+",\"swap\":"+N(swap,2)+",\"commission\":"+N(com,2)+",\"fee\":"+N(fee,2);
   j+=",\"position\":"+(string)pos+",\"magic\":"+(string)magic;
   j+=",\"comment\":\""+Esc(cmt)+"\"}";
   return j;
}

bool PostRaw(const string payload)
{
   char body[],res[]; string rh;
   int n=StringToCharArray(payload,body,0,WHOLE_ARRAY,CP_UTF8)-1; ArrayResize(body,n);
   string hdr="Content-Type: application/json\r\nX-API-Key: "+InpApiKey+"\r\n";
   int code=WebRequest("POST",InpServer+"/api/ea/trade",hdr,6000,body,res,rh);
   if(code==-1){ PrintFormat("WebRequest error %d — เพิ่มที่อยู่ในรายการ Allow WebRequest หรือเปิดแอปเซิร์ฟเวอร์หรือยัง?",GetLastError()); return false; }
   if(code==401){ Print("API key ไม่ถูกต้อง"); return false; }
   return code==200;
}

void Enqueue(const string json){ int k=ArraySize(g_queue); ArrayResize(g_queue,k+1); g_queue[k]=json; }

// ส่งเป็นชุดละไม่เกิน 40 ไม้ ถ้าเซิร์ฟเวอร์ปิดอยู่จะเก็บคิวไว้ส่งใหม่
void Flush()
{
   if(ArraySize(g_queue)==0){ PostRaw("[]"); return; }   // heartbeat ให้แอปรู้ว่า EA ยังอยู่
   while(ArraySize(g_queue)>0)
   {
      int cnt=MathMin(40,ArraySize(g_queue));
      string p="[";
      for(int i=0;i<cnt;i++){ if(i>0) p+=","; p+=g_queue[i]; }
      p+="]";
      if(!PostRaw(p)) return;
      int left=ArraySize(g_queue)-cnt;
      for(int i=0;i<left;i++) g_queue[i]=g_queue[i+cnt];
      ArrayResize(g_queue,left);
   }
}

int OnInit()
{
   if(InpApiKey==""){ Print("กรุณาใส่ InpApiKey"); return INIT_PARAMETERS_INCORRECT; }
   EventSetTimer(MathMax(5,InpRetrySec));
   if(InpBackfillDays>0 && HistorySelect(TimeCurrent()-InpBackfillDays*86400,TimeCurrent()+60))
   {
      int n=HistoryDealsTotal(); ulong tk[]; ArrayResize(tk,n);
      for(int i=0;i<n;i++) tk[i]=HistoryDealGetTicket(i);
      for(int i=0;i<n;i++){ string j=BuildJson(tk[i]); if(j!="") Enqueue(j); }
   }
   Flush();
   return INIT_SUCCEEDED;
}
void OnDeinit(const int reason){ EventKillTimer(); }
void OnTimer(){ Flush(); }

void OnTradeTransaction(const MqlTradeTransaction &t,const MqlTradeRequest &rq,const MqlTradeResult &rs)
{
   if(t.type!=TRADE_TRANSACTION_DEAL_ADD) return;
   string j=BuildJson(t.deal); if(j=="") return;
   Enqueue(j); Flush();
}
