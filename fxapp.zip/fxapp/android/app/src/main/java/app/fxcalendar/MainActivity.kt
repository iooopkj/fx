package app.fxcalendar

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var tries = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        startForegroundService(Intent(this, ServerService::class.java))
        web = WebView(this); setContentView(web)
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = false }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val sch = r.url.scheme
                if (sch == "http" || sch == "https") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) }
                catch (e: Exception) { Toast.makeText(this@MainActivity, "ไม่พบแอป Authenticator — คัดลอกรหัสไปใส่เองได้", Toast.LENGTH_LONG).show() }
                return true
            }
            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (r.isForMainFrame && tries++ < 20) v.postDelayed({ v.loadUrl(URL) }, 700)   // รอเซิร์ฟเวอร์บูต
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null); chooser = cb; startActivityForResult(p.createIntent(), 7); return true
            }
        }
        web.loadUrl(URL)
        val ips = ServerService.lanIps()
        if (ips.isNotEmpty()) Toast.makeText(this, "เพื่อนใน Wi-Fi เดียวกันเปิด http://${ips[0]}:${ServerService.PORT}", Toast.LENGTH_LONG).show()
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (r == 7) { chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c, d)); chooser = null }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    companion object { const val URL = "http://127.0.0.1:${ServerService.PORT}/" }
}
