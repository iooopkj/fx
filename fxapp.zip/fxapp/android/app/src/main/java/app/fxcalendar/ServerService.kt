package app.fxcalendar

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface

class ServerService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("fx", "FX server", NotificationManager.IMPORTANCE_LOW))
        val ips = lanIps()
        val txt = if (ips.isEmpty()) "ยังไม่ได้เชื่อม Wi-Fi" else "เปิดจากเครื่องอื่น: " + ips.joinToString(" , ") { "http://$it:$PORT" }
        val n = Notification.Builder(this, "fx").setContentTitle("FX Calendar กำลังทำงาน").setContentText(txt)
            .setStyle(Notification.BigTextStyle().bigText(txt)).setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (!started) {
            started = true
            (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "fx:srv").acquire()
            Thread {
                val web = File(filesDir, "web").also { it.mkdirs() }
                assets.list("web")?.forEach { nme -> assets.open("web/$nme").use { inp -> File(web, nme).outputStream().use { inp.copyTo(it) } } }
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                Python.getInstance().getModule("android_main").callAttr("start", web.path, filesDir.path, PORT)
            }.start()
        }
        return START_STICKY
    }

    companion object {
        const val PORT = 8000
        @Volatile var started = false
        fun lanIps(): List<String> = try {
            NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
                .flatMap { it.inetAddresses.toList() }.filter { it is Inet4Address && it.isSiteLocalAddress }.map { it.hostAddress!! }
        } catch (e: Exception) { emptyList() }
    }
}
