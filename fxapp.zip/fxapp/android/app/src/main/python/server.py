#!/usr/bin/env python3
"""FX Calendar server (stdlib only).   python server.py setup | python server.py [--host H] [--port P]
 - เข้าสู่ระบบ = รหัสผ่าน + OTP ครั้งที่ 1 (ส่งทางอีเมล)   - งานสำคัญ = OTP ครั้งที่ 2 (ส่งทางอีเมลอีกรอบ)
 - EA (MT5) ส่งออเดอร์เข้า /api/ea/trade ด้วย X-API-Key   - ข้อมูลแอปสำรองฝั่งเซิร์ฟเวอร์ผ่าน /api/store"""
import base64, hashlib, hmac, json, os, re, secrets, smtplib, socket, sqlite3, ssl, sys, time, getpass
from email.message import EmailMessage
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from urllib.parse import urlparse, parse_qs, quote

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.environ.get("FX_DB", os.path.join(ROOT, "fx.db"))
SECURE = os.environ.get("FX_HTTPS") == "1"
SENDER = os.environ.get("FX_SENDER", "phatsanariwanchai90@gmail.com")   # ผู้ส่ง OTP
SMTP_HOST, SMTP_PORT = os.environ.get("FX_SMTP_HOST", "smtp.gmail.com"), int(os.environ.get("FX_SMTP_PORT", 587))
STORE_KEYS = {"tc_v1", "mk_name", "mk_avatar", "mk_accent"}
SESS, PEND, FAILS, LOCK, SENT = {}, {}, {}, {}, {}
SETUP = {}   # OTP ของขั้นตั้งค่าครั้งแรก

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.executescript("""CREATE TABLE IF NOT EXISTS user(id INTEGER PRIMARY KEY, name TEXT UNIQUE, salt TEXT, pw TEXT, totp TEXT, last INTEGER DEFAULT 0, eakey TEXT);
    CREATE TABLE IF NOT EXISTS trades(id INTEGER PRIMARY KEY AUTOINCREMENT, ext TEXT UNIQUE, date TEXT, pair TEXT, pl REAL, note TEXT, ts INTEGER);
    CREATE TABLE IF NOT EXISTS store(k TEXT PRIMARY KEY, v TEXT, ts INTEGER);
    CREATE TABLE IF NOT EXISTS cfg(k TEXT PRIMARY KEY, v TEXT);""")
    for q in ("ALTER TABLE user ADD COLUMN ok INTEGER DEFAULT 1", "ALTER TABLE trades ADD COLUMN raw TEXT"):
        try: c.execute(q)
        except sqlite3.OperationalError: pass
    return c

def cfg_get(k, d=""):
    c = db(); r = c.execute("SELECT v FROM cfg WHERE k=?", (k,)).fetchone(); c.close(); return r["v"] if r else d
def cfg_set(**kw):
    c = db()
    for k, v in kw.items(): c.execute("INSERT OR REPLACE INTO cfg VALUES(?,?)", (k, str(v)))
    c.commit(); c.close()

def pbk(p, salt): return hashlib.pbkdf2_hmac("sha256", p.encode(), bytes.fromhex(salt), 200000).hex()
def sha(x): return hashlib.sha256(x.encode()).hexdigest()
def mask(e): a, _, d = e.partition("@"); return a[:2] + "***@" + d

# ---------- OTP ทางอีเมล ----------
def send_mail(to, subject, body, sender=None, pw=None):
    m = EmailMessage(); m["From"], m["To"], m["Subject"] = sender or cfg_get("sender", SENDER), to, subject; m.set_content(body)
    with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=20) as s:
        if os.environ.get("FX_SMTP_PLAIN") != "1":
            s.starttls(context=ssl.create_default_context()); s.login(sender or cfg_get("sender", SENDER), pw or cfg_get("smtp_pw"))
        s.send_message(m)

def mail_err(e):
    if isinstance(e, smtplib.SMTPAuthenticationError): return "Gmail ไม่ยอมรับรหัสผ่านแอป — ตรวจว่าเป็น App Password 16 ตัวของอีเมลผู้ส่ง"
    return "ส่งอีเมลไม่สำเร็จ — ตรวจว่าเครื่องต่ออินเทอร์เน็ตอยู่"

def issue(entry, to, purpose, sender=None, pw=None):
    """สร้างรหัส 6 หลัก เก็บเฉพาะ hash แล้วส่งอีเมล; คืน None ถ้าสำเร็จ หรือข้อความ error"""
    if time.time() - entry.get("sent", 0) < 20: return "รอสักครู่ก่อนขอรหัสใหม่ (20 วินาที)"
    code = "%06d" % secrets.randbelow(10**6)
    try: send_mail(to, f"{code} คือรหัสยืนยัน FX Calendar", f"รหัสยืนยัน ({purpose}) ของคุณคือ\n\n    {code}\n\nใช้ได้ 5 นาที ใช้ได้ครั้งเดียว\nถ้าคุณไม่ได้เป็นคนขอรหัสนี้ ให้เพิกเฉย และเปลี่ยนรหัสผ่านทันที", sender, pw)
    except Exception as e: return mail_err(e)
    entry.update(h=sha(code), exp=time.time() + 300, n=0, sent=time.time()); return None

def verify(entry, code):
    if not entry.get("h") or entry["exp"] < time.time() or entry["n"] >= 5: return False
    if hmac.compare_digest(sha(code), entry["h"]): entry["h"] = None; return True
    entry["n"] += 1; return False

# ---------- ผู้ใช้ / EA ----------
def create_user(name, pw, ok=1):
    salt, key = secrets.token_hex(16), secrets.token_urlsafe(32)
    c = db(); c.execute("DELETE FROM user")
    c.execute("INSERT INTO user(name,salt,pw,totp,eakey,ok) VALUES(?,?,?,?,?,?)", (name, salt, pbk(pw, salt), "", sha(key), ok)); c.commit(); c.close(); return key

def has_user():
    c = db(); r = c.execute("SELECT 1 FROM user WHERE ok=1").fetchone(); c.close(); return bool(r)

def lan_urls(port):
    ips = set()
    try:
        t = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); t.connect(("10.255.255.255", 1)); ips.add(t.getsockname()[0]); t.close()
    except Exception: pass
    try: ips.update(i[4][0] for i in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET))
    except Exception: pass
    return [f"http://{i}:{port}" for i in sorted(ips) if not i.startswith("127.")]

def ea_script(url="", key=""):
    for p in (os.path.join(ROOT, "ea", "TradeLogger.mq5"), os.path.join(ROOT, "TradeLogger.mq5")):
        if os.path.exists(p): s = open(p, encoding="utf8").read(); break
    else: return ""
    if url: s = re.sub(r'(input\s+string\s+InpServer\s*=\s*")[^"]*(")', lambda m: m.group(1) + url + m.group(2), s)
    if key: s = re.sub(r'(input\s+string\s+InpApiKey\s*=\s*")[^"]*(")', lambda m: m.group(1) + key + m.group(2), s)
    return s

def fnum(x):
    try: return format(float(x), "g")
    except Exception: return str(x)[:12]

def mk_note(t):
    """สรุปรายละเอียดไม้เป็นข้อความโน้ตในปฏิทิน"""
    if t.get("note"): return str(t["note"])[:300]
    p = []
    if t.get("side"): p.append(f'{str(t["side"]).upper()} {fnum(t.get("volume", ""))} lot')
    if t.get("open_price") is not None and t.get("close_price") is not None: p.append(f'เข้า {fnum(t["open_price"])} → ออก {fnum(t["close_price"])}')
    ot, ct = str(t.get("open_time", "")), str(t.get("close_time", ""))
    if len(ot) >= 16 and len(ct) >= 16: p.append(f"{ot[5:16]} → {ct[5:16]}")
    if t.get("sl"): p.append("SL " + fnum(t["sl"]))
    if t.get("tp"): p.append("TP " + fnum(t["tp"]))
    cost = [f"{n} {fnum(t[k])}" for k, n in (("swap", "swap"), ("commission", "คอม"), ("fee", "fee")) if t.get(k)]
    if cost: p.append(" ".join(cost))
    if t.get("comment"): p.append(str(t["comment"])[:40])
    if t.get("position"): p.append("#" + str(t["position"]))
    return " | ".join(p)[:300]

def setup():
    name = os.environ.get("FX_USER") or input("ชื่อผู้ใช้: ").strip()
    pw = os.environ.get("FX_PASS") or getpass.getpass("รหัสผ่าน (>=8 ตัว): ")
    if len(pw) < 8: sys.exit("รหัสผ่านสั้นเกินไป")
    rc = input("อีเมลผู้รับ OTP: ").strip(); ap = getpass.getpass(f"Gmail App Password ของผู้ส่ง ({SENDER}): ").replace(" ", "")
    e = {}; err = issue(e, rc, "ตั้งค่าครั้งแรก", SENDER, ap)
    if err: sys.exit(err)
    if not verify(e, input("กรอกรหัส 6 หลักที่ส่งไปอีเมล: ").strip()): sys.exit("รหัสไม่ถูกต้อง")
    key = create_user(name, pw); cfg_set(sender=SENDER, smtp_pw=ap, rcpt=rc)
    print(f"\nEA API key : {key}\n(แสดงครั้งเดียว ใส่ในช่อง InpApiKey ของ EA)")

SETUP_HTML = """<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>ตั้งค่าครั้งแรก</title>
<style>body{font-family:Kanit,sans-serif;background:#ffe2b8;color:#2b1a08;max-width:440px;margin:0 auto;padding:22px}input{width:100%;padding:13px;margin:5px 0;font-size:16px;border-radius:12px;border:1px solid #c90;box-sizing:border-box}
button,.b{display:block;width:100%;padding:14px;margin:8px 0;font-size:16px;border:0;border-radius:12px;background:#ff9a2e;font-weight:600;text-align:center;color:#2b1400;text-decoration:none;box-sizing:border-box}.g{background:#fff}
code{display:block;white-space:pre-wrap;word-break:break-all;background:#fff;padding:10px;border-radius:10px;font-size:15px}#e{color:#d12f45;min-height:20px}small,details{color:#6b4a1f;font-size:13px}label{font-size:13px;color:#6b4a1f}</style>
<h2>🔐 ตั้งค่าครั้งแรก</h2>
<div id=s1><p><b>ขั้น 1/3</b> บัญชีและอีเมล OTP</p>
<input id=n placeholder="ชื่อผู้ใช้" autocomplete=off><input id=p type=password placeholder="รหัสผ่าน (อย่างน้อย 8 ตัว)"><input id=p2 type=password placeholder="ยืนยันรหัสผ่านอีกครั้ง">
<label>อีเมลผู้รับรหัส OTP (อีเมลของคุณ)</label><input id=em type=email placeholder="you@gmail.com">
<label>อีเมลผู้ส่งรหัส OTP (กำหนดไว้แล้ว)</label><input value="__SENDER__" readonly style="background:#f3e4cc">
<label>รหัสผ่านแอป Gmail ของอีเมลผู้ส่ง (App Password 16 ตัว)</label><input id=ap placeholder="xxxx xxxx xxxx xxxx" autocomplete=off>
<details><summary>วิธีสร้างรหัสผ่านแอป Gmail</summary>1) เข้า myaccount.google.com ด้วยอีเมลผู้ส่ง → ความปลอดภัย<br>2) เปิด "การยืนยัน 2 ขั้นตอน"<br>3) ค้นหา "รหัสผ่านแอป" (App passwords) → ตั้งชื่อ FX → สร้าง<br>4) คัดลอกรหัส 16 ตัวมาวางที่นี่ (ไม่ใช่รหัสผ่าน Gmail ปกติ)</details>
<button onclick=a1()>ส่งรหัสยืนยันไปที่อีเมล</button></div>
<div id=s2 hidden><p><b>ขั้น 2/3</b> ใส่รหัส 6 หลักที่ส่งไปที่ <b id=to></b></p><input id=c inputmode=numeric maxlength=6 placeholder="000000" style="text-align:center;font-size:24px;letter-spacing:6px"><button onclick=a2()>ยืนยัน</button><button class=g onclick=rs()>ส่งรหัสอีกครั้ง</button></div>
<div id=s3 hidden><p><b>ขั้น 3/3</b> เสร็จแล้ว ✅</p><p>🔑 <b>EA API key</b> สำหรับ EA ของ Forex (MT5) — แสดงครั้งเดียว คัดลอกเก็บไว้</p><code id=k></code><button class=g onclick="cp('k')">คัดลอก API key</button>
<p>📡 <b>ที่อยู่เซิร์ฟเวอร์</b> ให้ EA และเครื่องอื่นใน Wi-Fi เดียวกันใช้เข้าเว็บ</p><code id=ur></code><button class=g onclick="cp('ur')">คัดลอกที่อยู่</button>
<p>📜 <b>สคริปต์ EA สำหรับ MT5</b> (ใส่ที่อยู่และ API key ให้แล้ว)</p><button class=g onclick="cp('',SC)">คัดลอกสคริปต์ EA</button>
<p><small>MT5 → File → Open Data Folder → MQL5 → Experts → สร้างไฟล์ TradeLogger.mq5 แล้ววางสคริปต์ → เปิด MetaEditor กด F7 คอมไพล์ → ลาก EA ลงกราฟ<br>เพิ่มที่อยู่เซิร์ฟเวอร์ที่ Tools → Options → Expert Advisors → Allow WebRequest<br>EA ทำงานคู่กับแอปนี้: ถ้าปิดแอป EA จะส่งไม่ได้ แต่จะเก็บคิวและส่งให้ใหม่เมื่อเปิดแอปอีกครั้ง</small></p>
<button onclick=location.reload()>เข้าสู่ระบบ</button></div><div id=e></div>
<script>const $=i=>document.getElementById(i);let SC='';const show=i=>['s1','s2','s3'].forEach(x=>$(x).hidden=x!=i);
async function post(u,b){$('e').textContent='กำลังดำเนินการ...';const r=await fetch(u,{method:'POST',body:JSON.stringify(b||{})}),j=await r.json();if(!r.ok){$('e').textContent=j.error;return null}$('e').textContent='';return j}
async function a1(){if($('p').value!==$('p2').value){$('e').textContent='รหัสผ่านสองช่องไม่ตรงกัน';return}const j=await post('/api/setup',{name:$('n').value.trim(),password:$('p').value,email:$('em').value.trim(),app_password:$('ap').value});if(!j)return;$('to').textContent=j.sent_to;show('s2')}
async function rs(){if(await post('/api/setup/resend'))$('e').textContent='ส่งรหัสใหม่แล้ว'}
async function a2(){const j=await post('/api/setup/confirm',{code:$('c').value.trim()});if(!j)return;$('k').textContent=j.key;SC=j.script;$('ur').textContent=j.urls.length?j.urls.join('\\n'):'ยังไม่พบ Wi-Fi — เชื่อม Wi-Fi แล้วดูที่อยู่ในเมนู EA & Wi-Fi ของแอป';show('s3')}
function cp(id,txt){const t=document.createElement('textarea');t.value=txt||$(id).textContent;document.body.append(t);t.select();try{document.execCommand('copy');$('e').textContent='คัดลอกแล้ว'}catch(e){}t.remove()}</script>"""

class H(BaseHTTPRequestHandler):
    server_version = "FX"
    def log_message(self, *a): pass
    def out(self, code, obj, cookie=None, ctype="application/json"):
        b = obj if isinstance(obj, bytes) else json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", ctype + "; charset=utf-8"); self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store"); self.send_header("X-Content-Type-Options", "nosniff"); self.send_header("X-Frame-Options", "SAMEORIGIN")
        if cookie: self.send_header("Set-Cookie", cookie)
        self.end_headers(); self.wfile.write(b)
    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 6_000_000: raise ValueError("big")
        return json.loads(self.rfile.read(n) or b"{}")
    def sid(self):
        m = SimpleCookie(self.headers.get("Cookie", "")).get("fx_sid"); return m.value if m else None
    def sess(self):
        s = SESS.get(self.sid())
        if s and s["exp"] < time.time(): SESS.pop(self.sid(), None); return None
        return s
    def ip(self): return self.client_address[0]
    def local(self): return self.ip() in ("127.0.0.1", "::1")
    def locked(self, k): return LOCK.get(k, 0) > time.time()
    def fail(self, k):
        FAILS[k] = FAILS.get(k, 0) + 1
        if FAILS[k] >= 5: LOCK[k] = time.time() + 60; FAILS[k] = 0
    def port(self): return self.server.server_address[1]

    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ("/", "/index.html"):
            if not has_user():   # ยังไม่เคยตั้งค่า: ตั้งได้เฉพาะจากตัวเครื่องเอง
                if not self.local(): return self.out(503, "รอเจ้าของเครื่องตั้งค่าในแอปก่อน".encode(), ctype="text/plain")
                return self.out(200, SETUP_HTML.replace("__SENDER__", SENDER).encode(), ctype="text/html")
            h = open(os.path.join(ROOT, "index.html"), encoding="utf8").read(); inj = open(os.path.join(ROOT, "sync.js"), encoding="utf8").read()
            a, _, z = h.rpartition("</body>")
            return self.out(200, (a + "<script>" + inj + "</script></body>" + z).encode(), ctype="text/html")
        ST = {"/manifest.webmanifest": "application/manifest+json", "/sw.js": "text/javascript", "/icon-192.png": "image/png", "/icon-512.png": "image/png"}
        if u.path in ST: return self.out(200, open(os.path.join(ROOT, u.path[1:]), "rb").read(), ctype=ST[u.path])
        if u.path == "/api/ping": return self.out(200, {"fxserver": 1})
        s = self.sess()
        if not s: return self.out(401, {"error": "ต้องเข้าสู่ระบบ"})
        c = db()
        try:
            if u.path == "/api/netinfo":
                return self.out(200, {"urls": lan_urls(self.port()), "ea_last": int(cfg_get("ea_last", "0") or 0), "trades": c.execute("SELECT COUNT(*) FROM trades").fetchone()[0], "rcpt": mask(cfg_get("rcpt", "@"))})
            if u.path == "/api/ea-script":
                us = lan_urls(self.port()); return self.out(200, ea_script(us[0] if us else f"http://127.0.0.1:{self.port()}").encode(), ctype="text/plain")
            if u.path == "/api/me": return self.out(200, {"user": s["user"], "stepup": s.get("up", 0) > time.time()})
            if u.path == "/api/trades":
                since = int((parse_qs(u.query).get("since") or ["0"])[0] or 0)
                r = c.execute("SELECT id,ext,date,pair,pl,note FROM trades WHERE id>? ORDER BY id LIMIT 2000", (since,)).fetchall()
                return self.out(200, {"trades": [{k: x[k] for k in ("ext", "date", "pair", "pl", "note")} for x in r], "latest": r[-1]["id"] if r else since})
            if u.path == "/api/store":
                return self.out(200, {"data": {x["k"]: {"v": x["v"], "ts": x["ts"]} for x in c.execute("SELECT * FROM store")}})
            if u.path == "/api/export":
                if s.get("up", 0) < time.time(): return self.out(403, {"error": "ต้องยืนยัน OTP ครั้งที่ 2", "need": "stepup"})
                return self.out(200, {"trades": [dict(x) for x in c.execute("SELECT * FROM trades")], "store": {x["k"]: x["v"] for x in c.execute("SELECT * FROM store")}})
        finally: c.close()
        self.out(404, {"error": "not found"})

    def do_POST(self):
        u = urlparse(self.path)
        try: d = self.body()
        except Exception: return self.out(400, {"error": "bad request"})
        c = db()
        try:
            if u.path in ("/api/setup", "/api/setup/resend", "/api/setup/confirm"):
                if has_user() or not self.local(): return self.out(403, {"error": "ตั้งค่าไปแล้ว"})
                if u.path == "/api/setup":   # ขั้น 1: ส่งรหัสทดสอบไปอีเมลผู้รับ — ถ้าส่งได้จึงเก็บค่า (ยังไม่เปิดใช้จนกว่าจะยืนยัน)
                    nm, pw, em, ap = str(d.get("name", "")).strip()[:40], str(d.get("password", "")), str(d.get("email", "")).strip(), str(d.get("app_password", "")).replace(" ", "")
                    if not nm or len(pw) < 8: return self.out(400, {"error": "ใส่ชื่อ และรหัสผ่านอย่างน้อย 8 ตัว"})
                    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", em): return self.out(400, {"error": "อีเมลผู้รับไม่ถูกต้อง"})
                    if len(ap) < 8: return self.out(400, {"error": "ใส่รหัสผ่านแอป Gmail ของผู้ส่ง"})
                    SETUP.clear(); err = issue(SETUP, em, "ตั้งค่าครั้งแรก", SENDER, ap)
                    if err: return self.out(502, {"error": err})
                    create_user(nm, pw, ok=0); cfg_set(sender=SENDER, smtp_pw=ap, rcpt=em); return self.out(200, {"sent_to": mask(em)})
                if not c.execute("SELECT 1 FROM user WHERE ok=0").fetchone(): return self.out(400, {"error": "เริ่มใหม่ที่ขั้นแรก"})
                if u.path == "/api/setup/resend":
                    err = issue(SETUP, cfg_get("rcpt"), "ตั้งค่าครั้งแรก"); return self.out(502 if err else 200, {"error": err} if err else {"ok": 1})
                if self.locked("C"): return self.out(429, {"error": "ลองผิดหลายครั้ง รอ 1 นาที"})
                if not verify(SETUP, str(d.get("code", ""))): self.fail("C"); return self.out(401, {"error": "รหัสไม่ถูกต้องหรือหมดอายุ"})
                key = secrets.token_urlsafe(32); c.execute("UPDATE user SET ok=1, eakey=?", (sha(key),)); c.commit(); us = lan_urls(self.port())
                return self.out(200, {"key": key, "urls": us, "script": ea_script(us[0] if us else f"http://127.0.0.1:{self.port()}", key)})
            if u.path == "/api/login":
                name, pw, k = str(d.get("email", "")), str(d.get("password", "")), "L" + self.ip()
                if self.locked(k): return self.out(429, {"error": "ลองผิดหลายครั้ง รอ 1 นาที"})
                r = c.execute("SELECT * FROM user WHERE ok=1 AND lower(name)=lower(?)", (name,)).fetchone()
                if not (r and hmac.compare_digest(pbk(pw, r["salt"]), r["pw"])): self.fail(k); return self.out(401, {"error": "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง"})
                p = {"uid": r["id"], "exp": time.time() + 300, "n": 0}; err = issue(p, cfg_get("rcpt"), "เข้าสู่ระบบ ครั้งที่ 1")
                if err: return self.out(429 if "รอสักครู่" in err else 502, {"error": err})
                t = secrets.token_urlsafe(24); PEND[t] = p; return self.out(200, {"token": t})
            if u.path == "/api/otp":
                tk = str(d.get("token", "")); p = PEND.get(tk)
                if not p or p["exp"] < time.time(): PEND.pop(tk, None); return self.out(401, {"error": "รหัสเข้าสู่ระบบหมดอายุ เริ่มใหม่"})
                if not verify(p, str(d.get("code", ""))):
                    if p["n"] >= 5: PEND.pop(tk, None); return self.out(429, {"error": "ใส่ OTP ผิดหลายครั้ง เริ่มใหม่"})
                    return self.out(401, {"error": "รหัส 6 หลักไม่ถูกต้อง"})
                PEND.pop(tk, None); r = c.execute("SELECT * FROM user WHERE id=?", (p["uid"],)).fetchone(); sid = secrets.token_urlsafe(32)
                SESS[sid] = {"user": r["name"], "uid": r["id"], "exp": time.time() + 43200}
                return self.out(200, {"ok": 1}, cookie=f"fx_sid={sid}; Path=/; HttpOnly; SameSite=Strict; Max-Age=43200" + ("; Secure" if SECURE else ""))
            if u.path == "/api/ea/trade":
                key = self.headers.get("X-API-Key", ""); k = "E" + self.ip()
                if self.locked(k): return self.out(429, {"error": "slow down"})
                r = c.execute("SELECT eakey FROM user WHERE ok=1 LIMIT 1").fetchone()
                if not (r and key and hmac.compare_digest(sha(key), r["eakey"])): self.fail(k); return self.out(401, {"error": "bad key"})
                items = d if isinstance(d, list) else [d]; n = 0
                for t in items[:500]:
                    ext, date, pair, pl = str(t.get("ext", ""))[:80], str(t.get("date", "")), str(t.get("pair", ""))[:20], t.get("pl")
                    if not (ext and re.fullmatch(r"\d{4}-\d{2}-\d{2}", date) and pair and isinstance(pl, (int, float))): continue
                    n += c.execute("INSERT OR IGNORE INTO trades(ext,date,pair,pl,note,ts,raw) VALUES(?,?,?,?,?,?,?)", (ext, date, pair, round(float(pl), 2), mk_note(t), int(time.time()), json.dumps(t, ensure_ascii=False)[:3000])).rowcount
                c.commit(); cfg_set(ea_last=int(time.time())); return self.out(200, {"added": n})
            s = self.sess()
            if u.path == "/api/logout":
                if s: SESS.pop(self.sid(), None)
                return self.out(200, {"ok": 1}, cookie="fx_sid=; Path=/; Max-Age=0")
            if not s: return self.out(401, {"error": "ต้องเข้าสู่ระบบ"})
            if u.path == "/api/stepup/send":   # OTP ครั้งที่ 2: ส่งรหัสใหม่ทางอีเมล
                err = issue(s.setdefault("otp2", {}), cfg_get("rcpt"), "ยืนยันครั้งที่ 2")
                return self.out(429 if err and "รอสักครู่" in err else 502, {"error": err}) if err else self.out(200, {"sent_to": mask(cfg_get("rcpt", "@"))})
            if u.path == "/api/stepup":
                k = "S" + str(s["uid"])
                if self.locked(k): return self.out(429, {"error": "ลองผิดหลายครั้ง รอ 1 นาที"})
                if not verify(s.setdefault("otp2", {}), str(d.get("code", ""))): self.fail(k); return self.out(401, {"error": "รหัสไม่ถูกต้องหรือหมดอายุ"})
                s["up"] = time.time() + 300; return self.out(200, {"ok": 1, "valid_sec": 300})
            if u.path == "/api/store":
                n = 0
                for k, v in (d.get("data") or {}).items():
                    if k in STORE_KEYS and isinstance(v, str): c.execute("INSERT OR REPLACE INTO store VALUES(?,?,?)", (k, v, int(time.time() * 1000))); n += 1
                c.commit(); return self.out(200, {"saved": n, "ts": int(time.time() * 1000)})
            if u.path == "/api/ea-key/rotate":
                if s.get("up", 0) < time.time(): return self.out(403, {"error": "ต้องยืนยัน OTP ครั้งที่ 2", "need": "stepup"})
                key = secrets.token_urlsafe(32); c.execute("UPDATE user SET eakey=?", (sha(key),)); c.commit(); return self.out(200, {"key": key})
        finally: c.close()
        self.out(404, {"error": "not found"})

if __name__ == "__main__":
    a = sys.argv[1:]
    if a[:1] == ["setup"]: setup(); sys.exit()
    host = a[a.index("--host") + 1] if "--host" in a else "127.0.0.1"; port = int(a[a.index("--port") + 1]) if "--port" in a else 8000
    print(f"FX server → http://{host}:{port}"); ThreadingHTTPServer((host, port), H).serve_forever()
