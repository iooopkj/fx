import os, threading
from http.server import ThreadingHTTPServer

def start(web_dir, data_dir, port=8000):
    """รัน server.py บนมือถือ; bind 0.0.0.0 เพื่อให้เครื่องอื่นใน Wi-Fi เดียวกันเข้าได้"""
    import server
    server.ROOT = web_dir
    server.DB = os.path.join(data_dir, "fx.db")
    srv = ThreadingHTTPServer(("0.0.0.0", port), server.H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return port
