/* ฉีดเข้า index.html โดย server: สำรอง localStorage ไปเก็บฝั่งเซิร์ฟเวอร์ + OTP ครั้งที่ 2 */
(()=>{const KEYS=['tc_v1','mk_name','mk_avatar','mk_accent'],ls=localStorage;
const api=(u,o)=>fetch(u,Object.assign({credentials:'same-origin',cache:'no-store'},o));
const put=b=>api('/api/store',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
let last='',timer;
const snap=()=>{const d={};KEYS.forEach(k=>{const v=ls.getItem(k);if(v!=null)d[k]=v});return d};
async function pull(){try{const r=await api('/api/store');if(!r.ok)return;const s=(await r.json()).data,seen=+ls.getItem('fx_store_ts')||0;let ch=0,mx=seen;
 for(const k of KEYS){const o=s[k];if(!o)continue;mx=Math.max(mx,o.ts);if((ls.getItem(k)==null||o.ts>seen&&JSON.stringify(snap())===last)&&ls.getItem(k)!==o.v){ls.setItem(k,o.v);ch=1}}
 ls.setItem('fx_store_ts',String(mx));last=JSON.stringify(snap());if(ch&&window.tcPL)window.tcPL()}catch(e){}}
async function push(){const d=snap(),j=JSON.stringify(d);if(j===last)return;try{const r=await put({data:d});if(r.ok){last=j;ls.setItem('fx_store_ts',String((await r.json()).ts))}}catch(e){}}
const st=window.fxStart;window.fxStart=()=>{if(st)st();pull().then(()=>{clearInterval(timer);timer=setInterval(push,10000)})};
addEventListener('pagehide',()=>{const d=snap();if(JSON.stringify(d)!==last)navigator.sendBeacon&&navigator.sendBeacon('/api/store',new Blob([JSON.stringify({data:d})],{type:'application/json'}))});
// ---- OTP ครั้งที่ 2 ----
window.fxStepUp=()=>new Promise(res=>{api('/api/me').then(r=>r.json()).then(m=>{if(m.stepup)return res(true);
 const o=document.createElement('div');o.style.cssText='position:fixed;inset:0;z-index:99;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;font-family:Kanit,sans-serif';
 o.innerHTML='<div style="background:#fff3e0;color:#2b1a08;border-radius:18px;padding:18px;width:min(88%,320px)"><b>ยืนยัน OTP ครั้งที่ 2</b><p style="font-size:13px;margin:6px 0">รอรหัสใหม่ในแอป (ห้ามใช้รหัสเดิมตอนเข้าสู่ระบบ)</p><input inputmode="numeric" maxlength="6" style="width:100%;font-size:22px;text-align:center;letter-spacing:6px;padding:8px;border-radius:10px;border:1px solid #c90"><div id="e" style="color:#d12f45;font-size:13px;min-height:18px"></div><button id="ok" style="width:100%;padding:10px;border:0;border-radius:12px;background:#ff9a2e;font:inherit;font-weight:600">ยืนยัน</button><button id="no" style="width:100%;padding:8px;border:0;background:none;font:inherit">ยกเลิก</button></div>';
 document.body.append(o);const i=o.querySelector('input'),e=o.querySelector('#e');i.focus();
 o.querySelector('#no').onclick=()=>{o.remove();res(false)};
 o.querySelector('#ok').onclick=async()=>{const r=await api('/api/stepup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:i.value})});if(r.ok){o.remove();res(true)}else e.textContent=(await r.json()).error}})});
// ห้องกุญแจและสำรองไฟล์ ต้องผ่าน OTP ครั้งที่ 2 ก่อน
['openKV','openBackup'].forEach(n=>{let f=window[n];Object.defineProperty(window,n,{configurable:true,get(){return f&&window.FXSRV?async function(){if(await window.fxStepUp())f.apply(this,arguments)}:f},set(v){f=v}})});
})();
