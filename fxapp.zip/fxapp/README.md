# FX Calendar — server + EA + Playwright

1. `python server.py setup`  → ตั้งชื่อ/รหัสผ่าน, สแกน otpauth URI ในแอป Authenticator, เก็บ EA API key
2. `python server.py`        → เปิด http://127.0.0.1:8000  (ข้อมูลเก็บใน fx.db; ใช้ HTTPS ให้ตั้ง FX_HTTPS=1)
3. EA: คัดลอก `ea/TradeLogger.mq5` ไป MQL5/Experts, คอมไพล์, เพิ่ม URL ใน Tools>Options>Expert Advisors>Allow WebRequest, ใส่ ApiKey
4. ทดสอบ: `pip install playwright && playwright install chromium` แล้ว
   `FX_USER=.. FX_PASS=.. FX_TOTP=<secret> FX_EAKEY=<key> python tests/e2e.py`

OTP ครั้งที่ 1 = ตอน login | OTP ครั้งที่ 2 = ก่อนเปิดห้องกุญแจ/สำรองไฟล์, export, หมุนคีย์ EA (ต้องเป็นรหัสถัดไป ใช้ซ้ำไม่ได้, มีผล 5 นาที)
