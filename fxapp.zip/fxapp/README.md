# FX Calendar — แอป + เซิร์ฟเวอร์ + EA (MT5)

**ครั้งแรกที่เปิดแอป** จะเป็นหน้าตั้งค่า: ชื่อผู้ใช้, รหัสผ่าน, อีเมลผู้รับ OTP, รหัสผ่านแอป Gmail ของผู้ส่ง (phatsanariwanchai90@gmail.com)
→ ระบบส่งรหัสทดสอบไปอีเมลผู้รับ → ยืนยัน → ได้ EA API key + สคริปต์ EA ให้คัดลอก

- OTP ครั้งที่ 1 = ตอนเข้าสู่ระบบ | OTP ครั้งที่ 2 = ก่อนเปิดห้องกุญแจ/สำรองไฟล์/export/สร้าง API key ใหม่ (ทั้งคู่ส่งทางอีเมล)
- เครื่องอื่นใน Wi-Fi เดียวกันเปิดเว็บที่ http://IP-เครื่อง:8000 ได้ (ดูที่อยู่ในเมนู ☰ → EA & Wi-Fi)
- EA: เมนู ☰ → EA & Wi-Fi → คัดลอกสคริปต์ → MT5: File > Open Data Folder > MQL5 > Experts > สร้าง TradeLogger.mq5 วาง → F7 → ลงกราฟ
- ทดสอบ: `pip install playwright && playwright install chromium && python tests/e2e.py`
- คอม: `FXCalendar.bat` / `FXCalendar.sh` | มือถือ: build APK จากโฟลเดอร์ android (ดู .github/workflows/apk.yml)
