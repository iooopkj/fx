#!/usr/bin/env python3
"""FX Calendar server (stdlib only).  python server.py setup | python server.py [--host H] [--port P]
- Login = รหัสผ่าน + OTP ครั้งที่ 1 (TOTP)   - งานสำคัญ (export / หมุนคีย์ EA / ห้องกุญแจ) = OTP ครั้งที่ 2 (step-up)
- EA ส่งออเดอร์ที่ POST /api/ea/trade ด้วย X-API-Key  - ข้อมูลแอปถูกสำรองฝั่งเซิร์ฟเวอร์ผ่าน /api/store"""
import base64, hashlib, hmac, json, os, secrets, sqlite3, struct, sys, time, getpass, re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from urllib.parse import urlparse, parse_qs

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.environ.get("FX_DB", os.path.join(ROOT, "fx.db"))
SECURE = os.environ.get("FX_HTTPS") == "1"
STORE_KEYS = {"tc_v1", "mk_name", "mk_avatar", "mk_accent"}
SESS, PEND, FAILS, LOCK = {}, {}, {}, {}   # in-memory

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.executescript("""CREATE TABLE IF NOT EXISTS user(id INTEGER PRIMARY KEY, name TEXT UNIQUE, salt TEXT, pw TEXT, totp TEXT, last INTEGER DEFAULT 0, eakey TEXT);
    CREATE TABLE IF NOT EXISTS trades(id INTEGER PRIMARY KEY AUTOINCREMENT, ext TEXT UNIQUE, date TEXT, pair TEXT, pl REAL, note TEXT, ts INTEGER);
    CREATE TABLE IF NOT EXISTS store(k TEXT PRIMARY KEY, v TEXT, ts INTEGER);""")
    return c

def pbk(p, salt): return hashlib.pbkdf2_hmac("sha256", p.encode(), bytes.fromhex(salt), 200000).hex()
def sha(x): return hashlib.sha256(x.encode()).hexdigest()
def totp(sec, n):
    h = hmac.new(base64.b32decode(sec), struct.pack(">Q", n), "sha1").digest(); o = h[19] & 15
    return "%06d" % ((struct.unpack(">I", h[o:o+4])[0] & 0x7fffffff) % 1000000)

def check_otp(u, code):
    """คืนค่า counter ที่ใช้ได้ (ใหม่กว่าที่เคยใช้) หรือ None — กันใช้รหัสซ้ำ"""
    n0 = int(time.time() // 30)
    for n in (n0 - 1, n0, n0 + 1):
        if n > u["last"] and hmac.compare_digest(totp(u["totp"], n), code):
            c = db(); c.execute("UPDATE user SET last=? WHERE id=?", (n, u["id"])); c.commit(); c.close(); return n
    return None

def setup():
    name = os.environ.get("FX_USER") or input("ชื่อผู้ใช้: ").strip()
    pw = os.environ.get("FX_PASS") or getpass.getpass("รหัสผ่าน (>=8 ตัว): ")
    if len(pw) < 8: sys.exit("รหัสผ่านสั้นเกินไป")
    salt, sec, key = secrets.token_hex(16), base64.b32encode(secrets.token_bytes(20)).decode(), secrets.token_urlsafe(32)
    c = db(); c.execute("DELETE FROM user")
    c.execute("INSERT INTO user(name,salt,pw,totp,eakey) VALUES(?,?,?,?,?)", (name, salt, pbk(pw, salt), sec, sha(key))); c.commit()
    print(f"\nTOTP secret : {sec}\notpauth URI : otpauth://totp/FXCalendar:{name}?secret={sec}&issuer=FXCalendar\n(เพิ่มใน Google Authenticator / Authy)\n\nEA API key  : {key}\n(ใส่ใน input ApiKey ของ EA — แสดงครั้งเดียว)")

class H(BaseHTTPRequestHandler):
    server_version = "FX"
    def log_message(self, *a): pass
    def out(self, code, obj, cookie=None, ctype="application/json"):
        b = obj if isinstance(obj, bytes) else json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", ctype + "; charset=utf-8"); self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store"); self.send_header("X-Content-Type-Options", "nosniff"); self.send_header("X-Frame-Options", "SAMEORIGIN")
        if cookie: self.send_header("Set-Cookie", cookie)
        self.end_headers(); self.wfile.write(b)
    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 6_000_000: raise ValueError("big")
        return json.loads(self.rfile.read(n) or b"{}")
    def sess(self):
        c = SimpleCookie(self.headers.get("Cookie", "")); m = c.get("fx_sid")
        s = SESS.get(m.value) if m else None
        if s and s["exp"] < time.time(): SESS.pop(m.value, None); return None
        return s
    def ip(self): return self.client_address[0]
    def locked(self, k):
        if LOCK.get(k, 0) > time.time(): return True
        return False
    def fail(self, k):
        FAILS[k] = FAILS.get(k, 0) + 1
        if FAILS[k] >= 5: LOCK[k] = time.time() + 60; FAILS[k] = 0

    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ("/", "/index.html"):
            h = open(os.path.join(ROOT, "index.html"), encoding="utf8").read()
            inj = open(os.path.join(ROOT, "sync.js"), encoding="utf8").read()
            a, _, z = h.rpartition("</body>")
            return self.out(200, (a + "<script>" + inj + "</script></body>" + z).encode(), ctype="text/html")
        if u.path == "/api/ping": return self.out(200, {"fxserver": 1})
        s = self.sess()
        if not s: return self.out(401, {"error": "ต้องเข้าสู่ระบบ"})
        c = db()
        try:
            if u.path == "/api/me": return self.out(200, {"user": s["user"], "stepup": s.get("up", 0) > time.time()})
            if u.path == "/api/trades":
                since = int((parse_qs(u.query).get("since") or ["0"])[0] or 0)
                r = c.execute("SELECT id,ext,date,pair,pl,note FROM trades WHERE id>? ORDER BY id LIMIT 2000", (since,)).fetchall()
                return self.out(200, {"trades": [{k: x[k] for k in ("ext", "date", "pair", "pl", "note")} for x in r], "latest": r[-1]["id"] if r else since})
            if u.path == "/api/store":
                return self.out(200, {"data": {x["k"]: {"v": x["v"], "ts": x["ts"]} for x in c.execute("SELECT * FROM store")}})
            if u.path == "/api/export":
                if s.get("up", 0) < time.time(): return self.out(403, {"error": "ต้องยืนยัน OTP ครั้งที่ 2", "need": "stepup"})
                return self.out(200, {"trades": [dict(x) for x in c.execute("SELECT * FROM trades")], "store": {x["k"]: x["v"] for x in c.execute("SELECT * FROM store")}})
        finally: c.close()
        self.out(404, {"error": "not found"})

    def do_POST(self):
        u = urlparse(self.path)
        try: d = self.body()
        except Exception: return self.out(400, {"error": "bad request"})
        c = db()
        try:
            if u.path == "/api/login":
                name, pw, k = str(d.get("email", "")), str(d.get("password", "")), "L" + self.ip()
                if self.locked(k): return self.out(429, {"error": "ลองผิดหลายครั้ง รอ 1 นาที"})
                r = c.execute("SELECT * FROM user WHERE lower(name)=lower(?)", (name,)).fetchone()
                ok = r and hmac.compare_digest(pbk(pw, r["salt"]), r["pw"])
                if not ok: self.fail(k); return self.out(401, {"error": "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง"})
                t = secrets.token_urlsafe(24); PEND[t] = {"uid": r["id"], "exp": time.time() + 300, "n": 0}
                return self.out(200, {"token": t})
            if u.path == "/api/otp":
                p = PEND.get(str(d.get("token", "")))
                if not p or p["exp"] < time.time(): PEND.pop(str(d.get("token", "")), None); return self.out(401, {"error": "รหัสเข้าสู่ระบบหมดอายุ เริ่มใหม่"})
                r = c.execute("SELECT * FROM user WHERE id=?", (p["uid"],)).fetchone()
                if check_otp(r, str(d.get("code", ""))) is None:
                    p["n"] += 1
                    if p["n"] >= 5: PEND.pop(d["token"], None); return self.out(429, {"error": "ใส่ OTP ผิดหลายครั้ง เริ่มใหม่"})
                    return self.out(401, {"error": "รหัส 6 หลักไม่ถูกต้อง"})
                PEND.pop(d["token"], None); sid = secrets.token_urlsafe(32); SESS[sid] = {"user": r["name"], "uid": r["id"], "exp": time.time() + 43200}
                return self.out(200, {"ok": 1}, cookie=f"fx_sid={sid}; Path=/; HttpOnly; SameSite=Strict; Max-Age=43200" + ("; Secure" if SECURE else ""))
            if u.path == "/api/ea/trade":
                key = self.headers.get("X-API-Key", ""); k = "E" + self.ip()
                if self.locked(k): return self.out(429, {"error": "slow down"})
                r = c.execute("SELECT eakey FROM user LIMIT 1").fetchone()
                if not (r and key and hmac.compare_digest(sha(key), r["eakey"])): self.fail(k); return self.out(401, {"error": "bad key"})
                items = d if isinstance(d, list) else [d]; n = 0
                for t in items[:500]:
                    ext, date, pair, pl = str(t.get("ext", ""))[:80], str(t.get("date", "")), str(t.get("pair", ""))[:20], t.get("pl")
                    if not (ext and re.fullmatch(r"\d{4}-\d{2}-\d{2}", date) and pair and isinstance(pl, (int, float))): continue
                    n += c.execute("INSERT OR IGNORE INTO trades(ext,date,pair,pl,note,ts) VALUES(?,?,?,?,?,?)", (ext, date, pair, round(float(pl), 2), str(t.get("note", ""))[:200], int(time.time()))).rowcount
                c.commit(); return self.out(200, {"added": n})
            s = self.sess()
            if u.path == "/api/logout":
                if s: SESS.pop(SimpleCookie(self.headers.get("Cookie")).get("fx_sid").value, None)
                return self.out(200, {"ok": 1}, cookie="fx_sid=; Path=/; Max-Age=0")
            if not s: return self.out(401, {"error": "ต้องเข้าสู่ระบบ"})
            if u.path == "/api/stepup":   # OTP ครั้งที่ 2 — ต้องเป็นรหัสคนละช่วงเวลากับตอน login
                k = "S" + str(s["uid"])
                if self.locked(k): return self.out(429, {"error": "ลองผิดหลายครั้ง รอ 1 นาที"})
                r = c.execute("SELECT * FROM user WHERE id=?", (s["uid"],)).fetchone()
                if check_otp(r, str(d.get("code", ""))) is None:
                    self.fail(k); return self.out(401, {"error": "รหัสไม่ถูกต้อง หรือเป็นรหัสที่ใช้ไปแล้ว (รอรหัสถัดไป ≤30 วิ)"})
                s["up"] = time.time() + 300; return self.out(200, {"ok": 1, "valid_sec": 300})
            if u.path == "/api/store":
                n = 0
                for k, v in (d.get("data") or {}).items():
                    if k in STORE_KEYS and isinstance(v, str):
                        c.execute("INSERT OR REPLACE INTO store VALUES(?,?,?)", (k, v, int(time.time() * 1000))); n += 1
                c.commit(); return self.out(200, {"saved": n, "ts": int(time.time() * 1000)})
            if u.path == "/api/ea-key/rotate":
                if s.get("up", 0) < time.time(): return self.out(403, {"error": "ต้องยืนยัน OTP ครั้งที่ 2", "need": "stepup"})
                key = secrets.token_urlsafe(32); c.execute("UPDATE user SET eakey=?", (sha(key),)); c.commit(); return self.out(200, {"key": key})
        finally: c.close()
        self.out(404, {"error": "not found"})

if __name__ == "__main__":
    a = sys.argv[1:]
    if a[:1] == ["setup"]: setup(); sys.exit()
    host = a[a.index("--host") + 1] if "--host" in a else "127.0.0.1"; port = int(a[a.index("--port") + 1]) if "--port" in a else 8000
    c = db(); ok = c.execute("SELECT 1 FROM user").fetchone(); c.close()
    if not ok: sys.exit("ยังไม่ได้ตั้งค่า: รัน  python server.py setup  ก่อน")
    print(f"FX server → http://{host}:{port}"); ThreadingHTTPServer((host, port), H).serve_forever()
