//+------------------------------------------------------------------+
//| TradeLogger.mq5 — บันทึกออเดอร์ที่ปิดแล้วส่งเข้าเซิร์ฟเวอร์อัตโนมัติ    |
//| ตั้งค่า: Tools > Options > Expert Advisors > Allow WebRequest      |
//|          แล้วเพิ่ม URL เซิร์ฟเวอร์ (เช่น http://127.0.0.1:8000)        |
//+------------------------------------------------------------------+
#property copyright "FX Calendar"
#property version   "1.00"
input string InpServer       = "http://127.0.0.1:8000"; // URL เซิร์ฟเวอร์
input string InpApiKey       = "";                      // EA API key จาก server.py setup
input int    InpBackfillDays = 7;                       // ส่งย้อนหลังตอนเริ่ม (เซิร์ฟเวอร์กันซ้ำให้)
input int    InpRetrySec     = 15;                      // ลองส่งใหม่ถ้าค้างคิว

string g_queue[];   // JSON ของแต่ละออเดอร์ที่ยังส่งไม่สำเร็จ

string Esc(string s){ StringReplace(s,"\\","\\\\"); StringReplace(s,"\"","\\\""); return s; }

string BuildJson(const ulong deal)
{
   ENUM_DEAL_ENTRY en=(ENUM_DEAL_ENTRY)HistoryDealGetInteger(deal,DEAL_ENTRY);
   ENUM_DEAL_TYPE  ty=(ENUM_DEAL_TYPE)HistoryDealGetInteger(deal,DEAL_TYPE);
   if(en!=DEAL_ENTRY_OUT && en!=DEAL_ENTRY_OUT_BY && en!=DEAL_ENTRY_INOUT) return "";  // เฉพาะดีลที่ปิดออเดอร์
   if(ty!=DEAL_TYPE_BUY && ty!=DEAL_TYPE_SELL) return "";
   double pl=HistoryDealGetDouble(deal,DEAL_PROFIT)+HistoryDealGetDouble(deal,DEAL_SWAP)
            +HistoryDealGetDouble(deal,DEAL_COMMISSION)+HistoryDealGetDouble(deal,DEAL_FEE);
   string date=TimeToString((datetime)HistoryDealGetInteger(deal,DEAL_TIME),TIME_DATE);
   StringReplace(date,".","-");
   string note=StringFormat("%s %.2f lot #%I64u %s",(ty==DEAL_TYPE_BUY?"ปิด Sell":"ปิด Buy"),
               HistoryDealGetDouble(deal,DEAL_VOLUME),HistoryDealGetInteger(deal,DEAL_POSITION_ID),
               HistoryDealGetString(deal,DEAL_COMMENT));
   return StringFormat("{\"ext\":\"mt5-%I64d-%I64u\",\"date\":\"%s\",\"pair\":\"%s\",\"pl\":%.2f,\"note\":\"%s\"}",
          AccountInfoInteger(ACCOUNT_LOGIN),deal,date,Esc(HistoryDealGetString(deal,DEAL_SYMBOL)),pl,Esc(note));
}

bool Post(const string json)
{
   char body[],res[]; string rh;
   int n=StringToCharArray("["+json+"]",body,0,WHOLE_ARRAY,CP_UTF8)-1; ArrayResize(body,n);
   string hdr="Content-Type: application/json\r\nX-API-Key: "+InpApiKey+"\r\n";
   int code=WebRequest("POST",InpServer+"/api/ea/trade",hdr,5000,body,res,rh);
   if(code==-1){ PrintFormat("WebRequest error %d (เพิ่ม URL ใน Allow WebRequest?)",GetLastError()); return false; }
   if(code==401){ Print("API key ไม่ถูกต้อง"); return false; }
   return code==200;
}

void Enqueue(const string json){ int k=ArraySize(g_queue); ArrayResize(g_queue,k+1); g_queue[k]=json; }

void Flush()
{
   while(ArraySize(g_queue)>0)
   {
      if(!Post(g_queue[0])) return;                    // เซิร์ฟเวอร์ล่ม → รอรอบหน้า
      int last=ArraySize(g_queue)-1;
      for(int i=0;i<last;i++) g_queue[i]=g_queue[i+1];
      ArrayResize(g_queue,last);
   }
}

int OnInit()
{
   if(InpApiKey==""){ Print("กรุณาใส่ InpApiKey"); return INIT_PARAMETERS_INCORRECT; }
   EventSetTimer(MathMax(5,InpRetrySec));
   if(InpBackfillDays>0 && HistorySelect(TimeCurrent()-InpBackfillDays*86400,TimeCurrent()+60))
      for(int i=0;i<HistoryDealsTotal();i++){ string j=BuildJson(HistoryDealGetTicket(i)); if(j!="") Enqueue(j); }
   Flush();
   return INIT_SUCCEEDED;
}
void OnDeinit(const int r){ EventKillTimer(); }
void OnTimer(){ Flush(); }

void OnTradeTransaction(const MqlTradeTransaction &t,const MqlTradeRequest &rq,const MqlTradeResult &rs)
{
   if(t.type!=TRADE_TRANSACTION_DEAL_ADD) return;
   if(!HistoryDealSelect(t.deal)) { HistorySelect(TimeCurrent()-86400,TimeCurrent()+60); if(!HistoryDealSelect(t.deal)) return; }
   string j=BuildJson(t.deal); if(j=="") return;
   Enqueue(j); Flush();
}
